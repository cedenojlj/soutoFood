<?php return array (
  'cart-item' => 'App\\Http\\Livewire\\CartItem',
  'cart-list' => 'App\\Http\\Livewire\\CartList',
  'check-out' => 'App\\Http\\Livewire\\CheckOut',
  'order-list' => 'App\\Http\\Livewire\\OrderList',
  'product-container' => 'App\\Http\\Livewire\\ProductContainer',
  'product-item' => 'App\\Http\\Livewire\\ProductItem',
  'product-lists' => 'App\\Http\\Livewire\\ProductLists',
);