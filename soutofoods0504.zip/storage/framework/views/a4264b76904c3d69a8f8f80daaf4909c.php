

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">          

            <div class="card mt-3">

                <div class="card-header">


                  <div style="display: flex; justify-content: space-between; align-items: center;">

                    <span id="card_title">
                      Vendors
                    </span>

                     
                </div>



                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    

                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Username</th>
                            <th scope="col">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          
                          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <tr>
                            <th scope="row"><?php echo e($user->id); ?></th>
                            <td> <?php echo e($user->name); ?> </td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">

                                  <a class="btn btn-primary" href="<?php echo e(route('users.edit', $user->id)); ?>"><?php echo e(Auth::user()->rol == 'admin'?'Edit':'View'); ?></a>

                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('DELETE'); ?>

                                  
                                  
                                </form>

                            </td>
                          </tr>
                              
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                          
                          
                        </tbody>
                      </table>  

                      <?php echo e($users->links()); ?>

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/users/index.blade.php ENDPATH**/ ?>