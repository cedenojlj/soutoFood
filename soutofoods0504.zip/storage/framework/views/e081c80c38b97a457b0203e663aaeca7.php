<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('itemnumber')); ?>

            <?php echo e(Form::text('itemnumber', $product->itemnumber, ['class' => 'form-control' . ($errors->has('itemnumber') ? ' is-invalid' : ''), 'placeholder' => 'Itemnumber'])); ?>

            <?php echo $errors->first('itemnumber', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('name')); ?>

            <?php echo e(Form::text('name', $product->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('description')); ?>

            <?php echo e(Form::text('description', $product->description, ['class' => 'form-control' . ($errors->has('description') ? ' is-invalid' : ''), 'placeholder' => 'Description'])); ?>

            <?php echo $errors->first('description', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('upc')); ?>

            <?php echo e(Form::text('upc', $product->upc, ['class' => 'form-control' . ($errors->has('upc') ? ' is-invalid' : ''), 'placeholder' => 'Upc'])); ?>

            <?php echo $errors->first('upc', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('pallet')); ?>

            <?php echo e(Form::text('pallet', $product->pallet, ['class' => 'form-control' . ($errors->has('pallet') ? ' is-invalid' : ''), 'placeholder' => 'Pallet'])); ?>

            <?php echo $errors->first('pallet', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('price')); ?>

            <?php echo e(Form::text('price', $product->price, ['class' => 'form-control' . ($errors->has('price') ? ' is-invalid' : ''), 'placeholder' => 'Price'])); ?>

            <?php echo $errors->first('price', '<div class="invalid-feedback">:message</div>'); ?>

        </div>


        


        <div class="form-group">            
            <?php echo e(Form::hidden('user_id', Auth::id(), ['class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''), 'placeholder' => 'User Id'])); ?>

            <?php echo $errors->first('user_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/product/form.blade.php ENDPATH**/ ?>