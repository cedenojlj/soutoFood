<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                
                <div class="card-header"><?php echo e(__('Order')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('errores')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session('errores')); ?>

                        </div>
                    <?php endif; ?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart-item', ['product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('LD75XeR')) {
    $componentId = $_instance->getRenderedChildComponentId('LD75XeR');
    $componentTag = $_instance->getRenderedChildComponentTagName('LD75XeR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LD75XeR');
} else {
    $response = \Livewire\Livewire::mount('cart-item', ['product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('LD75XeR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                   
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/addtocart/agregar.blade.php ENDPATH**/ ?>