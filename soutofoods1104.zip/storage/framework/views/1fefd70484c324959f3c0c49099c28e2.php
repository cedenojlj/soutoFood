

    <table class="table">
       
        <tbody>
            <tr>
                <td></td>
                <th style="font-size:16px"> <strong>Rebate #</strong></th>
                <td style="font-size:16px; "><strong><?php echo e("$ ". number_format($orden->rebate,2)); ?></strong></td>  
                <td></td>   
                <th style="font-size:16px"> <strong>Order:</strong></th>
                <td style="font-size:16px; "><strong><?php echo e($orderDate); ?></strong></td>               
                             
            </tr>    
            <tr>
                <td></td>
                <th style="font-size:16px; color:#fcbf43"> <strong>Customer:</strong></th>
                <td style="font-size:16px; border: 1px solid #000000;"><strong><?php echo e($customer->name); ?></strong></td>  
                <td></td>
                            
            </tr>   
            
            <tr>
                <td></td>
                <th style="font-size:16px; color:#fcbf43"> <strong>Vendor:</strong></th>
                <td style="font-size:16px; border: 1px solid #000000;"><strong><?php echo e(Auth::user()->name); ?></strong></td> 
                <td></td>                             
            </tr>   
           
        </tbody>
    </table>




<table >
       
    <tbody>
        <tr> 
            <td></td>           
            <th style="font-size:14px"> <strong>Notes:</strong></th>  
        </tr>    
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"><?php echo e($orden->comments); ?></td>     
                        
        </tr>    
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"></td>     
                        
        </tr>  
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"></td>     
                        
        </tr>  
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"></td>     
                        
        </tr>  
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"></td>     
                        
        </tr>  
        <tr>          
            <td></td>
            <td style="font-size:16px; border-bottom: 50px solid #000000;" colspan="6"></td>     
                        
        </tr>  

         
       
    </tbody>
</table>




<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/exports/rebate.blade.php ENDPATH**/ ?>