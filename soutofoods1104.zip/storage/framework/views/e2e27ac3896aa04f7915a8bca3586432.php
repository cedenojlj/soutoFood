
<div>

            <?php if($status): ?>

                <div class="alert alert-success" role="alert">
                    <?php echo e($status); ?>

                </div>

            <?php endif; ?>     

            <?php if($errores): ?>

                <div class="alert alert-danger" role="alert">

                    <?php echo e($errores); ?>


                </div>
                
            <?php endif; ?>

           <div class="text-center">

                <div wire:loading.inline-flex wire:target="submit">       

                    <button class="btn btn-primary" type="button" disabled>
                        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                        Processing...
                    </button>
                    
                </div>

            </div> 


            <div class="Container">

                        <?php if(!$general): ?>           
                        
                                 

                                <div class="row mb-4 mt-2" wire:loading.remove wire:target="submit">           

                                    <div class="col-md-6">                
                                        
                                        <input type="text" class="col form-control" wire:model="searchx" autocomplete="false">               
                                    
                                    </div>

                                    
                                </div> 
                                
                                
                                <div wire:loading.remove wire:target="submit">           

                                    <?php if(!empty($searchx)): ?>

                                        

                                        <div class="row mb-3">

                                            <div class="col-md-6">               
                                            
                                                    <select wire:model="idCustomer" class="form-select <?php $__errorArgs = ['idCustomer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="Default select example">
                                
                                                        <option selected>Open this select menu</option>
                                
                                                        <?php $__currentLoopData = $Customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                                                        
                                                    </select> 

                                                    <?php $__errorArgs = ['idCustomer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                            </div>
                                
                                        </div>
                                
                                        

                                        <div class="row mb-3">                
                                
                                            <div class="col-md-6">
                                
                                                <label for="email" class="col-form-label text-md-end">Email Customer</label>
                                                
                                                <input wire:model="email" id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" required>
                                
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        

                                        <div class="row mb-3">                
                                
                                            <div class="col-md-6">
                                
                                                <label for="email2" class="col-form-label text-md-end">Email Customer</label>
                                                
                                                <input wire:model="email2" id="email2" type="email2" class="form-control <?php $__errorArgs = ['email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email2" required>
                                
                                                <?php $__errorArgs = ['email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                         

                                         <div class="row mb-3">                
                                
                                            <div class="col-md-6">
                                
                                                <label for="addressBundle" class="col-form-label text-md-end">Customer Address</label>  

                                                <label class="form-control"><?php echo e(empty($this->Customer->address)?'Customer Address':$this->Customer->address); ?></label>


                                            </div>
                                        </div>

                                        

                                        <div class="row mb-3">                
                                
                                            <div class="col-md-6">
                                
                                                <label for="emailRep" class="col-form-label text-md-end">Sales Rep</label>
                                                
                                                

                                                <label class="form-control"><?php echo e(empty($this->Customer->emailRep)?'Sales Rep Email':$this->Customer->emailRep); ?></label>


                                            </div>
                                        </div>
                                
                                        

                                        <div class="row mb-3">                
                                
                                            <div class="col-md-6">
                                
                                                <label for="vendorEmail" class="col-form-label text-md-end">Email Vendor</label>
                                                
                                               
                                
                                                

                                                <label class="form-control"><?php echo e(Auth::user()->emailuser); ?></label>


                                            </div>
                                        </div>
                                                            
                                        
                                        

                                        <div class="row mb-3">                
                                
                                            <div class="col-md-6">
                                
                                                <label for="pin" class="col-form-label">PIN</label>
                                
                                                

                                                <input wire:model="pin" id="pin" type="<?php echo e($tipoInput); ?>" class="form-control <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pin" required autocomplete="off">
                                
                                                <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div> 

                                        

                                        <table class="table table-bordered">
                                            <thead align="center">
                                              <tr>
                                                    <th scope="col">Order Qty</th>                                                    
                                                    <th scope="col" colspan="3">Description</th>
                                                    <th scope="col">Scan Item UPC</th>
                                                    <th scope="col">Cases per Pallet</th>
                                                    <th scope="col">Food Show Deal</th>
                                                    <th scope="col">Notes $</th>
                                                    <th scope="col">Final Price $</th>                                                    
                                                    <th scope="col"><?php echo e(Auth::user()->date1); ?></th>
                                                    <th scope="col"><?php echo e(Auth::user()->date2); ?></th>
                                                    <th scope="col"><?php echo e(Auth::user()->date3); ?></th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                    
                                                <?php
                                    
                                                    $totalqty=0;
                                                    $totalpallet=0;
                                                    $totalqtyone=0;
                                                    $totalqtytwo=0;
                                                    $totalqtythree=0;
                                    
                                                ?>
                                    
                                    
                                                <?php if(session('carrito')): ?>
                                                                        
                                                    <?php $__currentLoopData = session('carrito'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                                        <tr>
                                                            <td><?php echo e($item['amount']); ?></td>
                                                            <td colspan="3"><?php echo e($item['name']); ?></td>
                                                            <td><?php echo e($item['upc']); ?></td>
                                                            <td><?php echo e($item['pallet']); ?></td>
                                                            <td><?php echo e('$ '. $item['price']); ?></td>
                                                            <td><?php echo e('$ '. $item['notes']); ?></td>
                                                            <td><?php echo e('$ '. $item['finalprice']); ?></td>
                                                            <td><?php echo e($item['qtyone']); ?></td>
                                                            <td><?php echo e($item['qtytwo']); ?></td>
                                                            <td><?php echo e($item['qtythree']); ?></td>
                                                            
                                                        </tr> 
                                    
                                                        <?php
                                                            $totalqty=$totalqty + $item['amount'];
                                                            $totalpallet=$totalpallet + $item['pallet'];
                                                            $totalqtyone=$totalqtyone + $item['qtyone'];
                                                            $totalqtytwo=$totalqtytwo + $item['qtytwo'];
                                                            $totalqtythree=$totalqtythree + $item['qtythree'];
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                                                        <tr>
                                                            <td><?php echo e($totalqty); ?></td>
                                                            <td colspan="3"></td>
                                                            <td></td>
                                                            <td><?php echo e($totalpallet); ?></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td><?php echo e($totalqtyone); ?></td>
                                                            <td><?php echo e($totalqtytwo); ?></td>
                                                            <td><?php echo e($totalqtythree); ?></td>
                                                            
                                                        </tr> 
                                    
                                                <?php else: ?>
                                    
                                                    <h6>No Product in the Cart</h6>  
                                                                  
                                                <?php endif; ?>  
                                                
                                            </tbody>   
                                            
                                        </table>

                                        

                                        <div class="row mb-3">                
                                
                                            <div class="col-md-6">
                                
                                                <label for="rebate" class="col-form-label">Rebate</label>
                                
                                                
                                
                                                <div class="input-group mb-3">

                                                    <span class="input-group-text">$</span>
                                                    <input wire:model.debounce.1000ms="rebate" id="rebate" type="number" step=".01" class="form-control" aria-label="Amount (to the nearest dollar)">
                                                    
                                                
                                                </div>
                                                
                                                
                                                
                                                
                                                <?php $__errorArgs = ['rebate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>                    

                                        
                                        
                                        <div class="row mb-3">                
                                
                                            <div class="col-md-6">
                                
                                                <label for="comments" class="col-form-label text-md-end">Comments</label>  
                                                
                                                <textarea wire:model="comments" class="form-control" name="comments" id="comments" rows="3"></textarea>  

                                            </div>
                                        </div>

                                        

                                        <div class="row mb-3">

                                            <div class="col-md-6">

                                                
                                                <button wire:click="submit" type="button" class="btn btn-primary">Checkout</button>
                                                <button type="button" wire:click="$emit('regresar')" name="" id="" class="btn btn-primary">Back</button> 

                                            </div>

                                        </div>
                                    
                                    <?php endif; ?>

                                </div>                             
                             
                        <?php endif; ?>       
                
            </div>            

            <div class="container">  

                    <?php if($mostrarOrdenCreada): ?>

                        <div class="row mt-3">
                            
                            <h5>Order: <a href="<?php echo e(url('export-order',[$lastId])); ?>" class="btn btn-primary"><?php echo e($Customer->name . " - ". Auth::user()->name . " .xlsx"); ?></a> </h5>
                            <h5>Date Order: <?php echo e($orderDate->format('m-d-Y')); ?></h5>
                        
                            <h5>Total Order: <?php echo e('$ ' . number_format($total,2)); ?></h5>
                            <h5>Rebate: <?php echo e('$ ' . number_format($rebate,2)); ?></h5>

                        </div>

                    <?php endif; ?>       
                    
            </div>

            <?php if($statusEmail): ?>

                <div class="alert alert-danger" role="alert">

                    <?php echo e($statusEmail); ?>


                </div>
            
            <?php endif; ?>
    
</div>


<?php /**PATH C:\xampp\htdocs\soutofoods\resources\views/livewire/check-out.blade.php ENDPATH**/ ?>